sexcheck <- read.table("plink.sexcheck", header=T,as.is=T)

problem <- sexcheck[sexcheck$STATUS == "PROBLEM",]
output <- problem[ ,c("FID", "IID")]


write.table(output,"sex_discrepancy.txt",sep="\t",row.names=FALSE, col.names=FALSE,quote=FALSE)
