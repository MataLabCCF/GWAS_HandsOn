datafile = read.table("logistic_results.assoc.logistic", header = TRUE)
sink("logistic_results.assoc_2.logistic")

removed= ""

cat(paste("CHR", "SNP", "BP","A1", "TEST", "NMISS", "OR", "STAT", "P", sep = " "))
cat("\n")
for (i in 1:nrow(datafile)){
  row <- datafile[i,]
  if(! is.na(row$P)){
    cat(paste(row$CHR, row$SNP, row$BP, row$A1, row$TEST, row$NMISS, row$OR, row$STAT, row$P,sep = " "))
    cat("\n")
  }
}
sink()
