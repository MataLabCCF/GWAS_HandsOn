datafile = read.table("HapMap_3_r3_13.bim", header = FALSE)
sink("subset_snp_chr_22.txt")

for (i in 1:nrow(datafile)){
  row <- datafile[i,]
  if(row$V4 >= 21595000 && row$V4 <= 21605000){
    cat(paste(row$V2, sep = " "))
    cat("\n")
  }
}
sink()
