data<- read.table(file="HapMap_3_r3_13_mds.mds",header=TRUE)
sink("covar_mds.txt")

cat(paste("FID", "IID", "C1","C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9", "C10" , sep = " "))
cat("\n")
for (i in 1:nrow(datafile)){
  row <- datafile[i,]
  cat(paste(row$FID, row$IID, row$C1, row$C2, row$C3, row$C4, row$C5, row$C6, row$C7, row$C8, row$C9, row$C10 , sep = " "))
  cat("\n")
}
sink()
